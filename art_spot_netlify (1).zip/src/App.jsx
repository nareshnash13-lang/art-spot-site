import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, X, Menu, ChevronRight, Star, Send, Mail, Phone, MessageCircle, Search, Filter, GalleryHorizontal } from "lucide-react";

// === QUICK CUSTOMIZATION ===
// Brand & contact
const BRAND = "ART_SPOT"; // ← your studio name
const TAGLINE = "Graphic Design • Digital Art • Visual Storytelling";
const PRIMARY_CONTACT_EMAIL = "naresash13@gmail.com"; // mailto target
const PRIMARY_CONTACT_PHONE = "+91 7401040132"; // tel target
const WHATSAPP_NUMBER = "+917401040132"; // for WhatsApp chat action

// === SAMPLE DATA (replace with your real services, portfolio, and products) ===
const SERVICES = [
  {
    title: "Logo & Brand Identity",
    blurb:
      "Strategic, memorable identities: logos, color systems, typography, and brand kits that scale across print and digital.",
    bullets: ["Logo suites", "Brand guidelines PDF", "Marketing collateral"],
  },
  {
    title: "Digital Art Commissions",
    blurb:
      "High-impact portraits, concept art, and stylized illustrations with cinematic lighting and premium textures.",
    bullets: ["Realistic portraits", "Caricatures", "Key art & posters"],
  },
  {
    title: "Social Media Design",
    blurb:
      "Bold, scroll-stopping campaigns: post sets, reels covers, thumbnails, and ad creatives optimized for performance.",
    bullets: ["Content kits", "Story/reel covers", "Ad banners"],
  },
];

const PORTFOLIO = [
  { id: 1, title: "Cinema Portrait — Gold Glow", tag: "Portrait", src: "https://images.unsplash.com/photo-1544005313-94ddf0286df2" },
  { id: 2, title: "Vibrant Village — Poster Art", tag: "Poster", src: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e" },
  { id: 3, title: "Game Splash — Neo Tropics", tag: "Key Art", src: "https://images.unsplash.com/photo-1511765224389-37f0e77cf0eb" },
  { id: 4, title: "Minimal Logo Grid", tag: "Branding", src: "https://images.unsplash.com/photo-1516641395110-51c5cf43fb3e" },
  { id: 5, title: "Candid Street — GTA Vibes", tag: "Photo Art", src: "https://images.unsplash.com/photo-1503342217505-b0a15cf70489" },
  { id: 6, title: "Oil-Paint Style — Lamp Glow", tag: "Illustration", src: "https://images.unsplash.com/photo-1494790108377-be9c29b29330" },
];

const PRODUCTS = [
  { id: "p1", name: "Custom Portrait (Ultra-Real)", price: 4999, tag: "Commission", img: "https://images.unsplash.com/photo-1544005313-94ddf0286df2", desc: "1 figure, cinematic lighting, print-ready (A3)." },
  { id: "p2", name: "Couple Caricature (Glossy)", price: 5999, tag: "Caricature", img: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e", desc: "Big heads, small bodies, premium finish." },
  { id: "p3", name: "Logo + Mini Brand Kit", price: 7999, tag: "Branding", img: "https://images.unsplash.com/photo-1516641395110-51c5cf43fb3e", desc: "Logo, color palette, type pairing, mockups." },
  { id: "p4", name: "Poster Art (Key Visual)", price: 6999, tag: "Poster", img: "https://images.unsplash.com/photo-1511765224389-37f0e77cf0eb", desc: "Theatrical poster / campaign key art." },
];

const REVIEWS = [
  { name: "Anita R.", text: "Loved the portrait—skin texture and lighting were unreal!", rating: 5 },
  { name: "Studio K", text: "Got a logo + social kit. Our engagement jumped immediately.", rating: 5 },
  { name: "Ravi", text: "Fast, friendly, and premium quality. Highly recommend.", rating: 5 },
];

const BLOG = [
  { slug: "color-psychology-2025", title: "Color Psychology for High-Conversion Creatives", date: "2025-08-01" },
  { slug: "caricature-style-guide", title: "Making Glossy Caricatures Feel Premium", date: "2025-07-25" },
];

// === Small helpers ===
const currency = (n) => `₹${n.toLocaleString("en-IN")}`;

const Chip = ({ children }) => (
  <span className="inline-flex items-center rounded-full border border-white/30 bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
    {children}
  </span>
);

const Section = ({ id, title, kicker, children }) => (
  <section id={id} className="py-16 sm:py-24">
    <div className="mx-auto max-w-7xl px-6">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="text-sm uppercase tracking-widest text-white/70">{kicker}</p>
          <h2 className="mt-1 text-3xl font-extrabold sm:text-4xl">{title}</h2>
        </div>
        <a href={`#${id}`} className="text-sm text-white/80 hover:text-white flex items-center gap-1">
          View all <ChevronRight size={18} />
        </a>
      </div>
      {children}
    </div>
  </section>
);

// === Cart Drawer ===
function Cart({ open, onClose, items, removeItem }) {
  const total = items.reduce((s, it) => s + it.price * it.qty, 0);
  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: 400, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 400, opacity: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 25 }}
          className="fixed right-0 top-0 z-50 h-screen w-full max-w-md bg-neutral-900/95 backdrop-blur-xl border-l border-white/10 shadow-2xl"
        >
          <div className="flex items-center justify-between p-5 border-b border-white/10">
            <h3 className="text-xl font-bold">Your Cart</h3>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full">
              <X />
            </button>
          </div>
          <div className="p-5 space-y-4 overflow-y-auto h-[calc(100vh-200px)]">
            {items.length === 0 && (
              <p className="text-white/70">Your cart is empty. Add a product to continue.</p>
            )}
            {items.map((it) => (
              <div key={it.id} className="flex gap-3 border border-white/10 rounded-2xl p-3">
                <img src={it.img} alt={it.name} className="h-16 w-16 rounded-xl object-cover" />
                <div className="flex-1">
                  <p className="font-semibold">{it.name}</p>
                  <p className="text-sm text-white/70">{currency(it.price)} × {it.qty}</p>
                </div>
                <button onClick={() => removeItem(it.id)} className="text-sm opacity-80 hover:opacity-100">Remove</button>
              </div>
            ))}
          </div>
          <div className="p-5 border-t border-white/10">
            <div className="flex items-center justify-between mb-4">
              <span className="text-white/70">Subtotal</span>
              <span className="text-lg font-bold">{currency(total)}</span>
            </div>
            <button
              onClick={() => {
                const subject = encodeURIComponent(`${BRAND} Inquiry — Cart Total ${currency(total)}`);
                const body = encodeURIComponent(
                  `Hi, I'd like to place an order.\n\nItems:\n${items
                    .map((i) => `• ${i.name} — ${currency(i.price)} × ${i.qty}`)
                    .join("\n")}\n\nTotal: ${currency(total)}\n\nMy details:`
                );
                window.location.href = `mailto:${PRIMARY_CONTACT_EMAIL}?subject=${subject}&body=${body}`;
              }}
              className="w-full rounded-2xl bg-blue-500 text-white font-semibold py-3 hover:bg-blue-600"
              disabled={items.length === 0}
            >
              Checkout via Email
            </button>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER.replace(/[^\d]/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="mt-3 block w-full text-center rounded-2xl border border-white/20 py-3 font-semibold hover:bg-white/10"
            >
              Chat on WhatsApp
            </a>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}

// === Floating Chat Widget (simple inquiry form) ===
function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  return (
    <>
      <button
        className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full bg-blue-500 text-white px-4 py-3 font-semibold shadow-xl hover:translate-y-[-1px] hover:bg-blue-600"
        onClick={() => setOpen((o) => !o)}
      >
        <MessageCircle size={18} /> Chat
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-20 right-6 z-40 w-[320px] rounded-2xl border border-white/10 bg-neutral-900/95 backdrop-blur-xl shadow-2xl"
          >
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <p className="font-semibold">Chat with {BRAND}</p>
              <button className="p-2 hover:bg-white/10 rounded-full" onClick={() => setOpen(false)}><X size={18} /></button>
            </div>
            <div className="p-4 space-y-3">
              <input
                placeholder="Your email or phone"
                className="w-full rounded-xl bg-white/10 px-3 py-2 outline-none placeholder:text-white/60"
              />
              <textarea
                placeholder="Tell us what you need (logo, portrait, etc.)"
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                className="h-24 w-full rounded-xl bg-white/10 px-3 py-2 outline-none placeholder:text-white/60"
              />
              <button
                onClick={() => {
                  const subject = encodeURIComponent(`${BRAND} — New Chat Inquiry`);
                  const body = encodeURIComponent(msg || "Hi! I'd like to know more.");
                  window.location.href = `mailto:${PRIMARY_CONTACT_EMAIL}?subject=${subject}&body=${body}`;
                }}
                className="w-full rounded-xl bg-blue-500 text-white font-semibold py-2 hover:bg-blue-600"
              >
                Send Inquiry
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// === Main App ===
export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState([]);
  const [productFilter, setProductFilter] = useState("All");

  const tags = useMemo(() => ["All", ...new Set(PRODUCTS.map((p) => p.tag))], []);
  const filtered = PRODUCTS.filter((p) => productFilter === "All" || p.tag === productFilter);

  const addToCart = (p) => {
    setCart((prev) => {
      const exists = prev.find((i) => i.id === p.id);
      if (exists) {
        return prev.map((i) => (i.id === p.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...p, qty: 1 }];
    });
  };
  const removeItem = (id) => setCart((prev) => prev.filter((i) => i.id !== id));

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-slate-900 to-blue-700 text-white">
      {/* NAV */}
      <header className="sticky top-0 z-40 bg-neutral-900/50 backdrop-blur supports-[backdrop-filter]:bg-neutral-900/30 border-b border-white/10">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
          <a href="#home" className="font-black tracking-tight text-lg sm:text-xl">{BRAND}</a>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#services" className="hover:opacity-90">Services</a>
            <a href="#portfolio" className="hover:opacity-90">Portfolio</a>
            <a href="#store" className="hover:opacity-90">Store</a>
            <a href="#reviews" className="hover:opacity-90">Reviews</a>
            <a href="#blog" className="hover:opacity-90">Blog</a>
            <a href="#contact" className="hover:opacity-90">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setCartOpen(true)} className="relative rounded-full p-2 hover:bg-white/10">
              <ShoppingCart />
              {cart.length > 0 && (
                <span className="absolute -right-1 -top-1 h-5 w-5 rounded-full bg-blue-500 text-white text-xs font-bold grid place-items-center">
                  {cart.reduce((s, i) => s + i.qty, 0)}
                </span>
              )}
            </button>
            <button className="md:hidden rounded-full p-2 hover:bg-white/10" onClick={() => setMobileOpen((o) => !o)}>
              <Menu />
            </button>
          </div>
        </div>
        <AnimatePresence>
          {mobileOpen && (
            <motion.nav
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden border-t border-white/10"
            >
              <div className="px-6 py-4 flex flex-col gap-3">
                {[
                  ["Services", "#services"],
                  ["Portfolio", "#portfolio"],
                  ["Store", "#store"],
                  ["Reviews", "#reviews"],
                  ["Blog", "#blog"],
                  ["Contact", "#contact"],
                ].map(([label, href]) => (
                  <a key={href} href={href} onClick={() => setMobileOpen(false)} className="text-lg">
                    {label}
                  </a>
                ))}
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>

      {/* HERO */}
      <section id="home" className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 py-20 sm:py-28">
          <div className="grid gap-12 md:grid-cols-2 items-center">
            <div>
              <div className="flex flex-wrap gap-2 mb-4">
                <Chip>Graphic Design</Chip>
                <Chip>Digital Art</Chip>
                <Chip>Branding</Chip>
              </div>
              <h1 className="text-4xl sm:text-6xl font-black leading-tight">
                Bold, colorful visuals that sell your story.
              </h1>
              <p className="mt-4 text-white/85 text-lg max-w-prose">
                {TAGLINE}. From cinematic portraits and glossy caricatures to high-converting brand systems, we craft visuals that convert.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#store" className="rounded-2xl bg-blue-500 text-white px-5 py-3 font-semibold shadow hover:translate-y-[-1px] hover:bg-blue-600">
                  Shop Commissions
                </a>
                <a href="#portfolio" className="rounded-2xl border border-blue-400/60 px-5 py-3 font-semibold hover:bg-blue-500/10">
                  See Portfolio
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] w-full rounded-3xl border border-white/20 bg-white/10 backdrop-blur-xl shadow-2xl overflow-hidden">
                <img src="https://images.unsplash.com/photo-1503341455253-b2e723bb3dbb" alt="Hero artwork" className="h-full w-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <Section id="services" title="Services" kicker="What we do">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s) => (
            <div key={s.title} className="group rounded-3xl border border-white/15 bg-white/10 p-6 backdrop-blur-xl hover:bg-white/15 transition">
              <h3 className="text-xl font-bold">{s.title}</h3>
              <p className="mt-2 text-white/80">{s.blurb}</p>
              <ul className="mt-4 space-y-1 text-white/80">
                {s.bullets.map((b) => (
                  <li key={b} className="flex items-center gap-2"><ChevronRight size={16} /> {b}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* PORTFOLIO */}
      <Section id="portfolio" title="Portfolio" kicker="Selected work">
        <div className="mb-4 flex items-center gap-2 text-white/85"><GalleryHorizontal size={18}/> Browse highlights</div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {PORTFOLIO.map((p) => (
            <figure key={p.id} className="group overflow-hidden rounded-3xl border border-white/15 bg-white/5">
              <img src={p.src} alt={p.title} className="h-64 w-full object-cover group-hover:scale-[1.02] transition" />
              <figcaption className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold">{p.title}</p>
                  <p className="text-sm text-white/70">{p.tag}</p>
                </div>
                <a href="#contact" className="text-sm underline underline-offset-4">Commission similar</a>
              </figcaption>
            </figure>
          ))}
        </div>
      </Section>

      {/* STORE */}
      <Section id="store" title="Online Store" kicker="Instant commissions & packs">
        <div className="mb-6 flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2" size={16} />
            <input
              placeholder="Search product name"
              onChange={(e) => {
                const q = e.target.value.toLowerCase();
                const elts = document.querySelectorAll("[data-product-name]");
                elts.forEach((el) => (el.parentElement.style.display = el.dataset.productName.includes(q) ? "" : "none"));
              }}
              className="rounded-xl bg-white/10 pl-9 pr-3 py-2 placeholder:text-white/60 outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter size={16} />
            <div className="flex gap-2 flex-wrap">
              {tags.map((t) => (
                <button
                  key={t}
                  onClick={() => setProductFilter(t)}
                  className={`rounded-full px-3 py-1 text-sm border ${
                    productFilter === t ? "bg-blue-500 text-white border-blue-500" : "border-white/20 hover:bg-blue-500/10"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <div key={p.id} className="rounded-3xl border border-white/15 bg-white/10 overflow-hidden">
              <img src={p.img} alt={p.name} className="h-48 w-full object-cover" />
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-bold" data-product-name={p.name.toLowerCase()}>{p.name}</h3>
                    <p className="text-sm text-white/75">{p.desc}</p>
                  </div>
                  <span className="rounded-full bg-blue-500/20 px-3 py-1 text-sm">{p.tag}</span>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-lg font-extrabold">{currency(p.price)}</span>
                  <button onClick={() => addToCart(p)} className="rounded-xl bg-blue-500 text-white font-semibold px-4 py-2 hover:bg-blue-600">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* REVIEWS */}
      <Section id="reviews" title="Reviews" kicker="What clients say">
        <div className="grid gap-6 md:grid-cols-3">
          {REVIEWS.map((r, idx) => (
            <div key={idx} className="rounded-3xl border border-white/15 bg-white/10 p-6">
              <div className="flex items-center gap-2">
                {Array.from({ length: r.rating }).map((_, i) => (
                  <Star key={i} size={16} fill="currentColor" />
                ))}
              </div>
              <p className="mt-3 text-white/85">“{r.text}”</p>
              <p className="mt-2 text-sm text-white/70">— {r.name}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* BLOG */}
      <Section id="blog" title="Blog" kicker="Insights & process">
        <div className="grid gap-6 md:grid-cols-2">
          {BLOG.map((b) => (
            <article key={b.slug} className="rounded-3xl border border-white/15 bg-white/10 p-6">
              <p className="text-sm text-white/70">{new Date(b.date).toLocaleDateString()}</p>
              <h3 className="mt-1 text-xl font-bold">{b.title}</h3>
              <p className="mt-2 text-white/85">Peek into our workflow, tools, and tips for keeping visuals premium yet efficient.</p>
              <a href="#contact" className="mt-3 inline-flex items-center gap-1 underline underline-offset-4">Read or request topic <ChevronRight size={16}/></a>
            </article>
          ))}
        </div>
      </Section>

      {/* CONTACT */}
      <Section id="contact" title="Contact" kicker="Start a project">
        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-3xl border border-white/15 bg-white/10 p-6">
            <h3 className="text-xl font-bold">Tell us about your project</h3>
            <form
              className="mt-4 grid gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                const data = new FormData(e.currentTarget);
                const subject = encodeURIComponent(`${BRAND} — New Project Inquiry`);
                const body = encodeURIComponent(
                  `Name: ${data.get("name")}
Email: ${data.get("email")}
Phone: ${data.get("phone")}
Service: ${data.get("service")}
Budget: ${data.get("budget")}

Message:
${data.get("message")}`
                );
                window.location.href = `mailto:${PRIMARY_CONTACT_EMAIL}?subject=${subject}&body=${body}`;
              }}
            >
              <input name="name" placeholder="Your name" className="rounded-xl bg-white/10 px-3 py-2 outline-none" required />
              <input name="email" type="email" placeholder="Email" className="rounded-xl bg-white/10 px-3 py-2 outline-none" required />
              <input name="phone" placeholder="Phone" className="rounded-xl bg-white/10 px-3 py-2 outline-none" />
              <select name="service" className="rounded-xl bg-white/10 px-3 py-2 outline-none">
                <option>Logo & Branding</option>
                <option>Digital Portrait</option>
                <option>Caricature</option>
                <option>Poster / Key Art</option>
                <option>Social Media Kit</option>
              </select>
              <select name="budget" className="rounded-xl bg-white/10 px-3 py-2 outline-none">
                <option>₹5k–10k</option>
                <option>₹10k–25k</option>
                <option>₹25k–50k</option>
                <option>₹50k+</option>
              </select>
              <textarea name="message" placeholder="Project details" className="min-h-[120px] rounded-xl bg-white/10 px-3 py-2 outline-none" />
              <button className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-blue-500 text-white font-semibold px-5 py-2 hover:bg-blue-600">
                <Send size={16}/> Send
              </button>
            </form>
          </div>
          <div className="rounded-3xl border border-white/15 bg-white/10 p-6">
            <h3 className="text-xl font-bold">Contact info</h3>
            <div className="mt-3 space-y-2 text-white/85">
              <a href={`mailto:${PRIMARY_CONTACT_EMAIL}`} className="flex items-center gap-2 hover:underline"><Mail size={16}/> {PRIMARY_CONTACT_EMAIL}</a>
              <a href={`tel:${PRIMARY_CONTACT_PHONE}`} className="flex items-center gap-2 hover:underline"><Phone size={16}/> {PRIMARY_CONTACT_PHONE}</a>
              <a href={`https://wa.me/${WHATSAPP_NUMBER.replace(/[^\d]/g, "")}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:underline"><MessageCircle size={16}/> WhatsApp</a>
            </div>
            <p className="mt-4 text-white/80">Office: Chennai, TN • Working worldwide (remote)</p>
            <p className="mt-2 text-white/70 text-sm">Mon–Sat • 10:00–19:00 IST</p>
          </div>
        </div>
      </Section>

      {/* FOOTER */}
      <footer className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-white/80">
          <p>© {new Date().getFullYear()} {BRAND}. All rights reserved.</p>
          <div className="flex items-center gap-3">
            <a href="#services" className="hover:opacity-100 opacity-80">Services</a>
            <a href="#store" className="hover:opacity-100 opacity-80">Store</a>
            <a href="#contact" className="hover:opacity-100 opacity-80">Contact</a>
          </div>
        </div>
      </footer>

      {/* Widgets */}
      <ChatWidget />
      <Cart open={cartOpen} onClose={() => setCartOpen(false)} items={cart} removeItem={removeItem} />
    </div>
  );
}
