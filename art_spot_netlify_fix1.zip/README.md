# ART_SPOT — Netlify Fix Build
- Adds missing `@vitejs/plugin-react`
- Sets `NODE_VERSION=18` for Netlify
Build:
- Build command: `npm run build`
- Publish directory: `dist`
