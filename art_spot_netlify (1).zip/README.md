# ART_SPOT — Netlify Deploy (React + Vite + Tailwind)

## Quick Start (Local)
1. Install Node.js 18+
2. In a terminal:
```bash
npm install
npm run dev
```
Visit http://localhost:5173

## Build
```bash
npm run build
```
Artifacts go to `dist/`.

## Netlify Deploy
1. Create a new site from your Netlify dashboard.
2. Connect to your GitHub repo **or** drag-and-drop the folder (after running `npm run build`) to Netlify Drop.
3. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. (Already included) `netlify.toml` sets SPA fallback.

## Customizing
- Edit `src/App.jsx` to change content (name, colors, products, portfolio, etc.).
- Update contact info at the top of `App.jsx`.
- Replace images in the arrays with your own URLs.

## Notes
- Email/WhatsApp checkout are simple starters. When ready, integrate Razorpay/Stripe for payments.
- Tailwind is preconfigured in `tailwind.config.js` and `src/index.css`.
