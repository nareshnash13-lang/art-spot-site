import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-slate-900 to-blue-700 text-white grid place-items-center">
      <div className="text-center p-8">
        <h1 className="text-4xl font-black">ART_SPOT</h1>
        <p className="text-white/80 mt-2">Netlify build test — if you see this, deploy works.</p>
      </div>
    </div>
  );
}
